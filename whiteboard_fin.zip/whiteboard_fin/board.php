<?php
session_start();
require 'db.php';
  if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM users WHERE id=".$user_id;
    $result = $conn->query($sql);
    if ($result->num_rows<1) {
      header('location: ./index.php');
    }
    
    $sql = "SELECT * FROM `users` WHERE id !=".$user_id;
    $result = $conn->query($sql);
  }else{
    header('location: ./index.php');
  }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>

<title> Whiteboard ICC </title>
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />

<!--CSS-->
<style type="text/css">
html, body {
  width:  100%;
  height: 100%;
}

#canvas {
  background-color: #333333;
  position: absolute;
  top: 35px;
}

#status {
  color: #FFFFFF;
  position: absolute;
  cursor: default;
  font-family: Helvetica, Verdana, sans-serif;
  font-weight: bold;
  margin: 10px;
  top: 30px;
}

#controls {
  background-color: #AAAAAA;
  font-family: Helvetica, Verdana, sans-serif;
  font-weight: bold;
  font-size: smaller;
  padding: 3px;
  width: 100vw;
  height: 25px;
}

select {
  font-family: monospace;
  font-size: medium;
}

* {
  padding:0;
  margin:0;
}
.users_list{
  /*position: absolute;
  float: right;
  top: 40px;*/
  /*margin-top: 40px;
  margin-left: 70vw;*/
  width: 100vw;
  height: 400px;
  display: flex;
}
.dummy_ele{
  width: 630px;
  min-height: 400px !important;
}
.list_elements{
  margin-left: 40px;
}
svg{
  color: #f00;
}
#controls a{
  margin-left: 30px;
  text-decoration: none;
  color: #4525ef;
}
</style>




</head>

<body>
  


<iframe src="https://socketio-whiteboard-zmx4.herokuapp.com/"  width="100%" height ="500px">

  
  <!--A status text field, for displaying connection information-->
  <div id="status"></div>
  <div class="users_list">
    <div class="dummy_ele"></div>
    <div class="list">
      <p>Users list</p>
      <ol class="list_elements">
        <?php
          while($row = $result->fetch_assoc()) {
        ?>
            <li>
              <?php echo $row['user_name']; ?>
              <a href="delete.php?id=<?php echo $row['id']; ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="29" height="14" viewBox="0 0 24 24" style="fill: rgba(255, 0, 0, 1);transform: ;msFilter:;"><path d="M6 7H5v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7H6zm4 12H8v-9h2v9zm6 0h-2v-9h2v9zm.618-15L15 2H9L7.382 4H3v2h18V4z"></path></svg>
              </a>
            </li>
        <?php
          }
        ?>
      </ol>
    </div>
  </div>
   <script src="https://unpkg.com/boxicons@2.1.1/dist/boxicons.js"></script>
</body>
</html>