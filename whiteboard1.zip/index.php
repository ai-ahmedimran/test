<?php
	session_start();
	require 'db.php';
	if (isset($_POST['login_btn'])) {
		$user_name = $_POST['user_name'];
    $query = "INSERT INTO `users`(`user_name`) VALUES ('$user_name')";
    if ($conn->query($query) === TRUE) {
    	$last_id = $conn->insert_id;
    	$_SESSION['user_id'] = $last_id;
			header("location: ./board.php");
		}
	}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Whiteboard/login</title>
  <link rel="stylesheet" href="./css/style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper">
	<div class="container">
		<h1>Welcome</h1>
		
		<form class="form" method="POST" action="./index.php">
			<input type="text" name="user_name" placeholder="Username">
			<button type="submit" name="login_btn" id="login-button">Enter</button>
			<?php
				if(isset($conn->error)){
					echo "<p>$conn->error</p>";
				}
			?>
		</form>
	</div>
	
<!-- 	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul> -->
</div>
<!-- partial -->
  <script src='./js/jquery.min.js'></script>
  <!-- <script  src="./js/script.js"></script> -->

</body>
</html>